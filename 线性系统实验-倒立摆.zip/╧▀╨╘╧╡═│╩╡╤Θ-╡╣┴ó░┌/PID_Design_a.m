%% Transfer Function - PID
clear
clc

% load PID parameter if existing, else use PID APP
try
    load PID_Parameter_a.mat
catch
    disp('please use PID APP')
end

% initial
M = 1.096;             % 小车质量
m = 0.109;             % 摆杆质量
b = 0.1;               % 小车与地面摩擦系数
L = 0.25;              % 摆杆轴心到质心距离
I = 0.0034;            % 摆杆绕质心的转动惯量
g = 9.8;               % 重力加速度

deg = pi/180;
x_0 = 0;               % 初始位置
dx_0 = 0;              % 初始速度
theta_0 = 10*deg;      % 初始角度
dtheta_0 = 0;          % 初始角速度

q = (M+m)*(I+m*L^2)-(m*L)^2;    % 中间变量

s = tf('s');
% a to theta
G_s = m*L/( (I+m*L^2)*s^2-m*g*L );

%% save the output from PID APP
Kp = C.Kp;
Ki = C.Ki;
Kd = C.Kd;

save PID_Parameter_a Kp Ki Kd

