clear
clc

% initial
deg = pi/180;
M = 1.096;             % 小车质量
m1 = 0.109;             % 摆杆质量
m2 = m1;
b = 0.1;               % 小车与地面摩擦系数
L1 = 0.25;              % 摆杆轴心到质心距离
L2 = L1;
I1 = 0.0034;            % 摆杆绕质心的转动惯量
I2 = I1;
g = 9.8;               % 重力加速度

S = [1 0 0 0 0 0;
    0 M+m1+m2 0 -m1*L1-2*m2*L1 0 -m2*L2;
    0 0 1 0 0 0;
    0 1 0 2*L1 0 (I2+m2*L2^2)/(m2*L2);
    0 0 0 0 1 0;
    0 2*m2*L1+m1*L1 0 -I1-m1*L1^2-4*m2*L1^2 0 -2*m2*L1*L2];
A0 = [0 1 0 0 0 0;
    0 -b 0 0 0 0;
    0 0 0 1 0 0;
    0 0 0 0 g 0;
    0 0 0 0 0 1;
    0 0 -(m1+m2)*g*L1 0 0 0];
B0 = [0;1;0;0;0;0];

A = S\A0;
B = S\B0;
C = [1 0 0 0 0 0;
    0 0 1 0 0 0;
    0 0 0 0 1 0];
D = [0;0;0];

sys = ss(A,B,C,D);

Q = [4 0 0 0 0 0;
     0 1 0 0 0 0;
     0 0 1/(15*deg)^2 0 0 0;
     0 0 0 1/(15*deg)^2 0 0;
     0 0 0 0 1/(15*deg)^2 0;
     0 0 0 0 0 1/(15*deg)^2];
R = 1;

[K,S,P] = lqr(sys,Q,R);

CC = eye(6);
DD = zeros(6,1);

%%
x = simout(:,1);
v = simout(:,2);
theta1 = simout(:,3);
omega1 = simout(:,4);
theta2 = simout(:,5);
omega2 = simout(:,6);

plot(t, x, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -0.5 0.1])
xlabel('t/s')
ylabel('x/m')


plot(t, v, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -3, 0.5])
xlabel('t/s')
ylabel('v/(m/s)')


plot(t, theta1*180/pi, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -8, 12])
xlabel('t/s')
ylabel('theta1/deg')


plot(t, omega1*180/pi, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -300, 50])
xlabel('t/s')
ylabel('omega1/(deg/s)')


plot(t, theta2*180/pi, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -8, 12])
xlabel('t/s')
ylabel('theta2/deg')


plot(t, omega2*180/pi, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -300, 50])
xlabel('t/s')
ylabel('omega2/(deg/s)')
