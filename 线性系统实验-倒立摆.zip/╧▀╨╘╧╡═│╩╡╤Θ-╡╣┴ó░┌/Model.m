function [sys,x0,str,ts,simStateCompliance] = Model(t,x,u,flag,M,m,b,L,g,I,x_0,dx_0,theta_0,dtheta_0)
switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes(x_0,dx_0,theta_0,dtheta_0);
  case 1,
    sys=mdlDerivatives(t,x,u,M,m,b,L,g,I);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes(x_0,dx_0,theta_0,dtheta_0)
sizes = simsizes;

sizes.NumContStates  = 4;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0  = [x_0, dx_0, theta_0, dtheta_0];
str = [];
ts  = [0 0];

simStateCompliance = 'UnknownSimState';

function sys=mdlDerivatives(t,x,u,M,m,b,L,g,I)
    F = u(1);                   % 作用力

    xx = x(1);                  % 位置
    xx_1 = x(2);                % 位置一阶导
    theta = x(3);               % 角度
    theta_1 = x(4);             % 角度一阶导
    % 位置二阶导
    xx_2 = ( F+m^2*L^2*g*sin(theta)*cos(theta)/(I+m*L^2)-m*L*sin(theta)*theta_1^2-b*theta_1 )...
        / (M+m-m^2*L^2*cos(theta)^2/(I+m*L^2));
    % 角度二阶导
    theta_2 = (m*g*sin(theta)*L+m*xx_2*cos(theta)*L) / (I+m*L^2);

    sys(1) = xx_1;
    sys(2) = xx_2;
    sys(3) = theta_1;
    sys(4) = theta_2;

function sys=mdlUpdate(t,x,u)
sys = [];

function sys=mdlOutputs(t,x,u)
    sys(1) = x(1);      % x
    sys(2) = x(2);      % dx
    sys(3) = x(3);      % theta
    sys(4) = x(4);      % dtheta

function sys=mdlGetTimeOfNextVarHit(t,x,u)
sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

function sys=mdlTerminate(t,x,u)
sys = [];
















