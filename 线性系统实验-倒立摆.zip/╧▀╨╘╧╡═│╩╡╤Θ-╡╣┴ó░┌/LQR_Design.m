%% LQR design
clear
clc

% initial
M = 1.096;             % 小车质量
m = 0.109;             % 摆杆质量
b = 0.1;               % 小车与地面摩擦系数
L = 0.25;              % 摆杆轴心到质心距离
I = 0.0034;            % 摆杆绕质心的转动惯量
g = 9.8;               % 重力加速度

deg = pi/180;
x_0 = 0;               % 初始位置
dx_0 = 0;              % 初始速度
theta_0 = 10*deg;      % 初始角度
dtheta_0 = 0;          % 初始角速度

q = (M+m)*(I+m*L^2)-(m*L)^2;    % 中间变量

% state space
A = [0 1 0 0;
     0 -(I+m*L^2)*b/q m^2*g*L^2/q 0;
     0 0 0 1;
     0 -m*b*L/q (M+m)*m*g*L/q 0];
B = [0; (I+m*L^2)/q; 0; m*L/q];
C = [1 0 0 0;
     0 0 1 0];
D = [0; 0];

sys = ss(A,B,C,D);

% diagonal matrix
Q = [4 0 0 0;
     0 1 0 0;
     0 0 1/(45*deg)^2 0;
     0 0 0 1/(30*deg)^2];
R = 1;

[K,S,P] = lqr(sys,Q,R);