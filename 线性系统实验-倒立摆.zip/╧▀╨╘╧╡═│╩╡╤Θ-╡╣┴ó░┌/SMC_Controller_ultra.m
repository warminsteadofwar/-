function [sys,x0,str,ts,simStateCompliance] = SMC_Controller_ultra(t,x,u,flag,M,m,b,L,g,I,cc,kk,epc)
switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u,M,m,b,L,g,I,cc,kk,epc);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes
sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];

simStateCompliance = 'UnknownSimState';

function sys=mdlDerivatives(t,x,u)
sys = [];

function sys=mdlUpdate(t,x,u)
sys = [];

function sys=mdlOutputs(t,x,u,M,m,b,L,g,I,cc,kk,epc)
    xx = u(1);
    xx_1 = u(2);
    theta = u(3);
    theta_1 = u(4);

    c1 = 1;
    c2 = 1;

    % while theta<0
    %     theta = theta+2*pi;
    % end
    % 
    % while theta>2*pi
    %     theta = theta-2*pi;
    % end

    s = c1*xx+c2*theta+xx_1+theta_1;
    
    % if abs(cos(theta))>0.3
        state1 = g*tan(theta)-kk*s-epc*sign(s)-c1*xx_1-c2*theta_1;
        state2 = (  (M+m)*(I+m*L^2)-m^2*L^2*cos(theta)^2  ) / (  (I+m*L^2)+m*cos(theta)*L  );
        state3 = m*L*sin(theta)*theta_1^2+b*theta_1-(M+m)*g*tan(theta);
        F = state1*state2 + state3;
    % else
    %     F = 0;
    % end

    sys(1) = F;
    sys(2) = s;

function sys=mdlGetTimeOfNextVarHit(t,x,u)
sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

function sys=mdlTerminate(t,x,u)
sys = [];
















