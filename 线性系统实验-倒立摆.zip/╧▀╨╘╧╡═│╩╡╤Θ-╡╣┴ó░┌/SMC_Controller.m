function [sys,x0,str,ts,simStateCompliance] = SMC_Controller(t,x,u,flag,M,m,b,L,g,I,cc,kk,epc)
switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u,M,m,b,L,g,I,cc,kk,epc);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end

function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes
sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0 0];

simStateCompliance = 'UnknownSimState';

function sys=mdlDerivatives(t,x,u)
sys = [];

function sys=mdlUpdate(t,x,u)
sys = [];

function sys=mdlOutputs(t,x,u,M,m,b,L,g,I,cc,kk,epc)
    xx = u(1);
    xx_1 = u(2);
    theta = u(3);
    theta_1 = u(4);

    e = L*cos(theta)-L;
    s = cc*(L*cos(theta)-L)-L*sin(theta)*theta_1;
    
    aa = 0.03;
    FF = 4;

    if abs(sin(theta))>aa && abs(cos(theta))>aa
        state1 = b*xx_1+m*L*sin(theta)*theta_1^2-(M+m)*g*tan(theta);
        state2 = ( (M+m)*(I+m*L^2)-m^2*L^2*cos(theta)^2 ) / ( m*sin(theta)*cos(theta)*L^2 );
        state3 = (kk*s+epc*sign(s)-cc*L*sin(theta)*theta_1-L*cos(theta)*theta_1^2);
        F = state1 + state2*state3;
    elseif cos(theta)<0 && abs(sin(theta))<=0.03
        F = FF;
    else
        F = 0;
    end

    sys(1) = F;
    sys(2) = s;

function sys=mdlGetTimeOfNextVarHit(t,x,u)
sampleTime = 1;    %  Example, set the next hit to be one second later.
sys = t + sampleTime;

function sys=mdlTerminate(t,x,u)
sys = [];
















