%% �����������
clear
clc
close all

g = 9.8;
v = 641;

% �������
ksi = 0.7;
wn = 20;
k0 = 5;

% ���
f_engine = 15;
wn_engine = 2*pi*f_engine;
G_engine = tf(wn_engine^2, [1, 2*0.7*wn_engine, wn_engine^2]);   % ������ݺ���

a2_now = 102.2;
a3_now = 67.2;
a4_now = 1.152;

k_w = (0-2*ksi*wn) / a3_now
k_alpha = (a2_now-wn^2) / (0-2*ksi*wn) - 0
k_n= k0*g/(v*a4_now);

s = tf('s');

% ���ݺ���
wz_deltaz = -a3_now*(s+a4_now) / (s^2+a4_now*s+a2_now);
alpha_wz = 1 / (s+a4_now);
ny_alpha = a4_now*v/g;

% �����· 
Gwz_open = k_w*wz_deltaz*G_engine;
Gwz_close = feedback(Gwz_open, 1);
[Gm1, Pm1, ~, Wcp1] = margin(Gwz_open);     % 20*log10(Gm) ��õ���ֵԣ��
Gm1 = 20*log10(Gm1);

% ���Ȼ�·
Galpha_open = k_alpha*Gwz_close*alpha_wz;
Galpha_close = feedback(Galpha_open, 1);
[Gm2, Pm2, ~, Wcp2] = margin(Galpha_open);
Gm2 = 20*log10(Gm2);

% ���ٻ�·
Gny_open = k_n / s * Galpha_close * ny_alpha;
Gny_close = feedback(Gny_open, 1);
[Gm3, Pm3, ~, Wcp3] = margin(Gny_open);
Gm3 = 20*log10(Gm3);

state = stepinfo(Gny_close);
rise_time = state.RiseTime
over_shoot = state.Overshoot
settling_time = state.SettlingTime;
state = stepinfo(Galpha_close);
alpha_over_shoot = state.Overshoot

Gm_min = min([Gm1, Gm2, Gm3]);
Pm_min = min([Pm1, Pm2, Pm3]);
if Gm_min<10 || Pm_min<60
    disp('False')
end

subplot(2,3,1)
margin(Gwz_open)
grid on

subplot(2,3,2)
margin(Galpha_open)
grid on

subplot(2,3,3)
margin(Gny_open)
grid on

subplot(2,3,4)
step(Gwz_close)
grid on

subplot(2,3,5)
step(Galpha_close)
grid on

subplot(2,3,6)
step(Gny_close)
grid on
