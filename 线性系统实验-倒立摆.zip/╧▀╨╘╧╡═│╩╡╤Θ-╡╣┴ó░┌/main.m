clear
clc

% initial
M = 1.096;          % 小车质量
m = 0.109;          % 摆杆质量
b = 0.1;               % 小车与地面摩擦系数
L = 0.25;             % 摆杆轴心到质心距离
I = 0.0034;          % 摆杆绕质心的转动惯量
g = 9.8;                % 重力加速度

% 过渡参数
q = (M+m)*(I+m*L^2)-(m*L)^2;

% state - space
% A = [0 1 0 0;
%         0   -(I+m*L^2)*b/q   m^2*L^2*g/q   0;
%         0 0 0 1;
%         0   -b*m*L/q   m*g*L*(M+m)/q   0];
% B = [0;   (I+m*L^2)/q;   0;   m*L/q];
% C = [1 0 0 0;
%         0 0 1 0];
% D = [0; 0];
A = [0 1 0 0;
     0 0 0 0;
     0 0 0 1;
     0 0 29.4 0];
B = [0;1;0;3];
C = [1 0 0 0;
     0 1 0 0;
     0 0 1 0;
     0 0 0 1];
D = [0;0;0;0];

sys = ss(A,B,C,D);

% 布莱森法则确定Q, R
Q = [10,0,0,0;...
    0,0,0,0;...
    0,0,10,0;...
    0,0,0,0];
R = 0.1;


%% Transfer Function PID
s = tf('s');
G_s = m*L/(   (I+m*L^2)*s^2-m*g*L   );
Kp = 233.2;
Ki = 666.8;
Kd = 20.39;


%% Pole placement design
% ksi >= 0.5, wn >= 4;
ksi = 0.9;
wn = 6;
s1 = -ksi*wn + wn*sqrt(1-ksi^2)*1i;
s2 = -ksi*wn - wn*sqrt(1-ksi^2)*1i;
s3 = -10 + 0.0001*1i;
s4 = -10 - 0.0001*1i;
p = [s1, s2, s3, s4];
K = place(A,B,p);

% ksi = 0.5, wn = 4
% K = [-69.2814  -31.2766  120.9460   21.8685];

% ksi = 0.6, wn = 5
% K = [-108.2522  -47.7310  156.3442   28.8838];

% ksi = 0.7, wn = 6;
% K = [-155.8832  -67.6494  199.2314   37.3670];


%% LQR
[K,S,P] = lqr(sys,Q,R)

% K = [-1.0000   -2.0381   30.1662    5.7548];

%% 绘图
x = simout(:,1);
v = simout(:,2);
theta = simout(:,3);
omega = simout(:,4);

plot(t, x, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -0.5 0.1])
xlabel('t/s')
ylabel('x/m')


plot(t, v, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -3, 0.5])
xlabel('t/s')
ylabel('v/(m/s)')


plot(t, theta*180/pi, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -8, 12])
xlabel('t/s')
ylabel('theta/deg')


plot(t, omega*180/pi, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -300, 50])
xlabel('t/s')
ylabel('omega/(deg/s)')

plot(t, energy, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
axis([-1, 11, -0.3, 0.35])
xlabel('t/s')
ylabel('E/J')

plot(t, fflag, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
axis([-1, 11, 0, 5])
xlabel('t/s')
ylabel('flag')

plot(t, ss, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
axis([-1, 11, -2, 0.5])
xlabel('t/s')
ylabel('s')

%% LQR_1
clear
clc

load LQR_1
pos = simout;
t = tt;
angle = simout1;

plot(t, pos, 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
xlabel('t/s')
ylabel('x/m')

%% 实验画图
plot(t(1:5000), Pos(1:5000), 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -0.5 0.1])
xlabel('t/s')
ylabel('x/m')

plot(t(1:5000), (-angle(1:5000)*180/pi+180), 'LineWidth', 1.5)
set(gca, 'linewidth', 1.5, 'fontsize', 16, 'fontname', 'times')
% axis([-1, 11, -30, 200])
xlabel('t/s')
ylabel('theta/deg')